## Repository for the Empowerment and Turnover Literature Review

A repo for the academic review of the empowerment and turnover literature conducted by the Center for Democracy and Civic Engagement

To view the GitHub Page site for this document, which includes options to download the PDF and Microsoft Word Document versions of the report, follow this [link](https://isaiahespi.github.io/cdce_empowerment/)